-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: coloc_app
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `colocataires`
--

DROP TABLE IF EXISTS `colocataires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colocataires` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `date_ajout` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_colocataires_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colocataires`
--

LOCK TABLES `colocataires` WRITE;
/*!40000 ALTER TABLE `colocataires` DISABLE KEYS */;
INSERT INTO `colocataires` VALUES (1,'Lema','/uploads/b0b2a5da4b5e41fe92e45b036a919211.png','2026-07-02 04:35:13'),(2,'Damamy','/uploads/8a734f8da6ea421abf05c25ce2e5cb1f.png','2026-07-02 04:35:27'),(3,'Dora','/uploads/f086d32fef664b4c8f12b24e320442b1.png','2026-07-02 04:35:37');
/*!40000 ALTER TABLE `colocataires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depenses`
--

DROP TABLE IF EXISTS `depenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `depenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `colocataire_id` int NOT NULL,
  `nom_produit` varchar(150) NOT NULL,
  `prix` float NOT NULL,
  `description` text,
  `date_ajout` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `colocataire_id` (`colocataire_id`),
  KEY `ix_depenses_id` (`id`),
  CONSTRAINT `depenses_ibfk_1` FOREIGN KEY (`colocataire_id`) REFERENCES `colocataires` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depenses`
--

LOCK TABLES `depenses` WRITE;
/*!40000 ALTER TABLE `depenses` DISABLE KEYS */;
INSERT INTO `depenses` VALUES (1,1,'depense farany',4000,NULL,'2026-07-02 04:38:09'),(2,2,'depense farany',1300,NULL,'2026-07-02 04:38:31'),(3,3,'depense farany',4500,NULL,'2026-07-02 04:38:59'),(4,1,'Tongolo',500,NULL,'2026-07-02 07:56:39'),(5,2,'Sakamalao',300,NULL,'2026-07-02 07:56:58'),(6,2,'Légumes',2800,NULL,'2026-07-05 15:25:50');
/*!40000 ALTER TABLE `depenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riz_contributions`
--

DROP TABLE IF EXISTS `riz_contributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `riz_contributions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `colocataire_id` int NOT NULL,
  `kg` float NOT NULL,
  `date_ajout` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `colocataire_id` (`colocataire_id`),
  KEY `ix_riz_contributions_id` (`id`),
  CONSTRAINT `riz_contributions_ibfk_1` FOREIGN KEY (`colocataire_id`) REFERENCES `colocataires` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riz_contributions`
--

LOCK TABLES `riz_contributions` WRITE;
/*!40000 ALTER TABLE `riz_contributions` DISABLE KEYS */;
INSERT INTO `riz_contributions` VALUES (1,2,17,'2026-07-02 04:35:55'),(2,3,13,'2026-07-02 04:36:07'),(3,1,21,'2026-07-02 04:36:15'),(4,1,29.5,'2026-07-02 09:38:37'),(5,3,5.5,'2026-07-02 09:39:40'),(7,3,1.8,'2026-07-08 19:00:18');
/*!40000 ALTER TABLE `riz_contributions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-08 19:50:16
